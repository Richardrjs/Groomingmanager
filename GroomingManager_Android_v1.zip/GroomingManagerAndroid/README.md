# Grooming Manager Android v1

Aplicación Android local para peluquería canina.

## Funciones
- Clientes
- Mascotas
- Historial de servicios
- Citas
- Caja
- Inventario
- Panel de resumen
- Almacenamiento local en el teléfono

## Crear el APK con Android Studio

1. Instala Android Studio en una computadora.
2. Descomprime este proyecto.
3. Abre Android Studio.
4. Selecciona **Open** y elige la carpeta `GroomingManagerAndroid`.
5. Espera a que termine **Gradle Sync**.
6. Ve a **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. El APK se generará normalmente en:
   `app/build/outputs/apk/debug/app-debug.apk`
8. Copia ese archivo al teléfono e instálalo.

Android puede pedir permiso para instalar aplicaciones provenientes del navegador o del administrador de archivos.

## Datos

Los datos se guardan localmente dentro de la aplicación Android. Al desinstalar la app se eliminan.
Esta versión no sincroniza varios dispositivos ni tiene copias de seguridad automáticas.

## Próxima versión recomendada
- Copia de seguridad y restauración.
- Usuarios y contraseña.
- Recordatorios por WhatsApp.
- Reportes PDF/Excel.
- Fidelización.
- Sincronización en la nube.
