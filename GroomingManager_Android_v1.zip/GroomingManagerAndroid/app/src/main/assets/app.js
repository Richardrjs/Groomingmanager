const DB_KEY = 'grooming_manager_mobile_v1';

const sample = {
  clients:[{id:1,name:'María González',phone:'6000-0000',email:'maria@example.com',notes:'Cliente demo'}],
  pets:[{id:1,clientId:1,name:'Luna',species:'Perro',breed:'Poodle',sex:'Hembra',weight:'6.5',allergies:'Ninguna',behavior:'Nerviosa con el secador',vaccines:'Al día',notes:'Usar shampoo suave'}],
  appointments:[{id:1,clientId:1,petId:1,date:new Date(Date.now()+86400000).toISOString().slice(0,10),time:'09:00',service:'Baño y corte',status:'CONFIRMADA',price:25,notes:''}],
  history:[{id:1,petId:1,date:new Date().toISOString().slice(0,10),service:'Baño',price:20,groomer:'Richard',products:'Shampoo hipoalergénico',notes:'Buen comportamiento'}],
  cash:[{id:1,date:new Date().toISOString().slice(0,10),type:'INGRESO',category:'Servicio',description:'Baño de Luna',amount:20,method:'Efectivo'}],
  inventory:[{id:1,name:'Shampoo hipoalergénico',category:'Higiene',quantity:2,minStock:3,cost:12,price:18,supplier:'Proveedor Demo',notes:''}]
};

let db = loadDB();
let deferredPrompt = null;

function loadDB(){
  const raw = localStorage.getItem(DB_KEY);
  if(!raw){ localStorage.setItem(DB_KEY, JSON.stringify(sample)); return structuredClone(sample); }
  try{return JSON.parse(raw)}catch{return structuredClone(sample)}
}
function save(){ localStorage.setItem(DB_KEY, JSON.stringify(db)); renderAll(); }
function nextId(arr){ return arr.length ? Math.max(...arr.map(x=>x.id))+1 : 1; }
function money(v){ return '$'+Number(v||0).toFixed(2); }
function clientName(id){ return db.clients.find(x=>x.id==id)?.name || '—'; }
function petName(id){ return db.pets.find(x=>x.id==id)?.name || '—'; }

document.querySelectorAll('.bottom-nav button').forEach(btn=>{
  btn.addEventListener('click',()=>{
    document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));
    document.getElementById(btn.dataset.screen).classList.add('active');
    document.querySelectorAll('.bottom-nav button').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
  });
});
document.querySelector('.bottom-nav button[data-screen="home"]').classList.add('active');

function renderAll(){
  const income = db.cash.filter(x=>x.type==='INGRESO').reduce((a,b)=>a+Number(b.amount||0),0);
  const expense = db.cash.filter(x=>x.type==='GASTO').reduce((a,b)=>a+Number(b.amount||0),0);
  document.getElementById('statClients').textContent=db.clients.length;
  document.getElementById('statPets').textContent=db.pets.length;
  document.getElementById('statAppointments').textContent=db.appointments.length;
  document.getElementById('statBalance').textContent=money(income-expense);
  document.getElementById('cashIncome').textContent=money(income);
  document.getElementById('cashExpense').textContent=money(expense);

  renderList('upcomingList', db.appointments.slice().sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time)).slice(0,5),
    a=>`<div class="item"><div><h3>${a.date} · ${a.time}</h3><p>${clientName(a.clientId)} / ${petName(a.petId)}</p><p>${a.service}</p></div><span class="badge">${a.status}</span></div>`);
  renderList('lowStockList', db.inventory.filter(x=>Number(x.quantity)<=Number(x.minStock)),
    x=>`<div class="item low"><div><h3>${x.name}</h3><p>Quedan ${x.quantity}; mínimo ${x.minStock}</p></div></div>`);

  renderList('clientsList', db.clients, c=>`<div class="item"><div><h3>${c.name}</h3><p>${c.phone||''}</p><p>${c.email||''}</p></div><button onclick="deleteItem('clients',${c.id})">Eliminar</button></div>`);
  renderList('petsList', db.pets, p=>`<div class="item"><div><h3>${p.name}</h3><p>${clientName(p.clientId)} · ${p.species||''} ${p.breed||''}</p><p>${p.behavior||''}</p></div><button onclick="openHistory(${p.id})">Historial</button></div>`);
  renderList('appointmentsList', db.appointments.slice().sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time)),
    a=>`<div class="item"><div><h3>${a.date} · ${a.time}</h3><p>${clientName(a.clientId)} / ${petName(a.petId)}</p><p>${a.service} · ${money(a.price)}</p></div><button onclick="cycleStatus(${a.id})">${a.status}</button></div>`);
  renderList('cashList', db.cash.slice().reverse(),
    m=>`<div class="item"><div><h3>${m.description}</h3><p>${m.date} · ${m.category||''}</p></div><strong>${m.type==='GASTO'?'-':'+'}${money(m.amount)}</strong></div>`);
  renderList('inventoryList', db.inventory,
    x=>`<div class="item ${Number(x.quantity)<=Number(x.minStock)?'low':''}"><div><h3>${x.name}</h3><p>${x.category||''} · Cantidad: ${x.quantity}</p><p>Precio: ${money(x.price)}</p></div><button onclick="adjustStock(${x.id})">Stock</button></div>`);
}
function renderList(id, items, template){
  document.getElementById(id).innerHTML = items.length ? items.map(template).join('') : '<div class="empty">Sin registros.</div>';
}
function deleteItem(type,id){
  if(confirm('¿Eliminar este registro?')){ db[type]=db[type].filter(x=>x.id!==id); save(); }
}

const modal=document.getElementById('modal');
const modalTitle=document.getElementById('modalTitle');
const modalBody=document.getElementById('modalBody');

function openModal(title, html, onSave){
  modalTitle.textContent=title; modalBody.innerHTML=html;
  const form=document.getElementById('modalForm');
  form.onsubmit=(e)=>{ e.preventDefault(); const data=Object.fromEntries(new FormData(form)); onSave(data); modal.close(); };
  modal.showModal();
}
function optionList(items,labelFn){ return items.map(x=>`<option value="${x.id}">${labelFn(x)}</option>`).join(''); }

function openClientForm(){
  openModal('Nuevo cliente',`
    <label>Nombre<input name="name" required></label>
    <label>Teléfono<input name="phone"></label>
    <label>Email<input name="email" type="email"></label>
    <label class="wide">Notas<textarea name="notes"></textarea></label>
    <div class="actions wide"><button type="submit">Guardar</button></div>`,
    d=>{db.clients.push({id:nextId(db.clients),...d});save();}
  );
}
function openPetForm(){
  openModal('Nueva mascota',`
    <label>Cliente<select name="clientId" required>${optionList(db.clients,x=>x.name)}</select></label>
    <label>Nombre<input name="name" required></label>
    <label>Especie<input name="species" value="Perro"></label>
    <label>Raza<input name="breed"></label>
    <label>Sexo<select name="sex"><option></option><option>Macho</option><option>Hembra</option></select></label>
    <label>Peso<input name="weight" type="number" step="0.1"></label>
    <label class="wide">Alergias<textarea name="allergies"></textarea></label>
    <label class="wide">Comportamiento<textarea name="behavior"></textarea></label>
    <label class="wide">Vacunas<textarea name="vaccines"></textarea></label>
    <label class="wide">Notas<textarea name="notes"></textarea></label>
    <div class="actions wide"><button type="submit">Guardar</button></div>`,
    d=>{d.clientId=Number(d.clientId);db.pets.push({id:nextId(db.pets),...d});save();}
  );
}
function openAppointmentForm(){
  openModal('Nueva cita',`
    <label>Cliente<select name="clientId">${optionList(db.clients,x=>x.name)}</select></label>
    <label>Mascota<select name="petId">${optionList(db.pets,x=>x.name)}</select></label>
    <label>Fecha<input name="date" type="date" required></label>
    <label>Hora<input name="time" type="time" required></label>
    <label>Servicio<input name="service" required></label>
    <label>Precio<input name="price" type="number" step="0.01"></label>
    <label>Estado<select name="status"><option>PENDIENTE</option><option>CONFIRMADA</option><option>COMPLETADA</option><option>CANCELADA</option></select></label>
    <label class="wide">Notas<textarea name="notes"></textarea></label>
    <div class="actions wide"><button type="submit">Guardar</button></div>`,
    d=>{d.clientId=Number(d.clientId);d.petId=Number(d.petId);d.price=Number(d.price||0);db.appointments.push({id:nextId(db.appointments),...d});save();}
  );
}
function openCashForm(){
  openModal('Movimiento de caja',`
    <label>Fecha<input name="date" type="date" required></label>
    <label>Tipo<select name="type"><option>INGRESO</option><option>GASTO</option></select></label>
    <label>Categoría<input name="category"></label>
    <label>Monto<input name="amount" type="number" step="0.01" required></label>
    <label>Método<select name="method"><option>Efectivo</option><option>Yappy</option><option>Transferencia</option><option>Tarjeta</option></select></label>
    <label class="wide">Descripción<textarea name="description" required></textarea></label>
    <div class="actions wide"><button type="submit">Guardar</button></div>`,
    d=>{d.amount=Number(d.amount||0);db.cash.push({id:nextId(db.cash),...d});save();}
  );
}
function openInventoryForm(){
  openModal('Nuevo producto',`
    <label>Nombre<input name="name" required></label>
    <label>Categoría<input name="category"></label>
    <label>Cantidad<input name="quantity" type="number" step="0.01"></label>
    <label>Stock mínimo<input name="minStock" type="number" step="0.01"></label>
    <label>Costo<input name="cost" type="number" step="0.01"></label>
    <label>Precio<input name="price" type="number" step="0.01"></label>
    <label>Proveedor<input name="supplier"></label>
    <label class="wide">Notas<textarea name="notes"></textarea></label>
    <div class="actions wide"><button type="submit">Guardar</button></div>`,
    d=>{['quantity','minStock','cost','price'].forEach(k=>d[k]=Number(d[k]||0));db.inventory.push({id:nextId(db.inventory),...d});save();}
  );
}
function openHistory(petId){
  const pet=db.pets.find(x=>x.id===petId);
  const entries=db.history.filter(x=>x.petId===petId);
  openModal(`Historial de ${pet.name}`,`
    <div class="wide">${entries.length?entries.map(h=>`<div class="item"><div><h3>${h.date} · ${h.service}</h3><p>${money(h.price)} · ${h.groomer||''}</p><p>${h.notes||''}</p></div></div>`).join(''):'<div class="empty">Sin servicios.</div>'}</div>
    <label>Fecha<input name="date" type="date" required></label>
    <label>Servicio<input name="service" required></label>
    <label>Precio<input name="price" type="number" step="0.01"></label>
    <label>Groomer<input name="groomer"></label>
    <label class="wide">Productos usados<textarea name="products"></textarea></label>
    <label class="wide">Notas<textarea name="notes"></textarea></label>
    <div class="actions wide"><button type="submit">Agregar servicio</button></div>`,
    d=>{d.petId=petId;d.price=Number(d.price||0);db.history.push({id:nextId(db.history),...d});save();}
  );
}
function cycleStatus(id){
  const states=['PENDIENTE','CONFIRMADA','COMPLETADA','CANCELADA'];
  const a=db.appointments.find(x=>x.id===id); a.status=states[(states.indexOf(a.status)+1)%states.length]; save();
}
function adjustStock(id){
  const item=db.inventory.find(x=>x.id===id);
  const value=prompt(`Nueva cantidad para ${item.name}`,item.quantity);
  if(value!==null && !isNaN(Number(value))){item.quantity=Number(value);save();}
}

window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredPrompt=e;document.getElementById('installBtn').hidden=false});
document.getElementById('installBtn').addEventListener('click',async()=>{if(deferredPrompt){deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;}});
if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('sw.js'))}
renderAll();
